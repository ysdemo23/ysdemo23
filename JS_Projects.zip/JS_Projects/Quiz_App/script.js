const questions=[
    {
        question:'Which of the following is a markup language?',
        answers:[
            {text:'HTML',correct:true},
            {text:'CSS',correct:false},
            {text:'JavaScript',correct:false},
            {text:'Python',correct:false},
        ]
    },
    {
        question:'Which of the following is a programming language?',
        answers:[
            {text:'HTML',correct:false},
            {text:'CSS',correct:false},
            {text:'JavaScript',correct:true},
            {text:'XML',correct:false}, 
        ]
    },
    {
        question:'Which of the following is used for styling web pages?',
        answers:[   
            {text:'HTML',correct:false},
            {text:'CSS',correct:true},
            {text:'JavaScript',correct:false},  
            {text:'SQL',correct:false},
        ]
    },
    {
        question:'Which of the following is a database query language?',
        answers:[   
            {text:'HTML',correct:false},
            {text:'CSS',correct:false},
            {text:'JavaScript',correct:false},
            {text:'SQL',correct:true},
        ]
    },
];

const questionElement=document.getElementById('question');
const answerButtons=document.getElementById('answer-buttons');
const nextButton=document.getElementById('next-btn');

let currentQuestionIndex=0;
let score=0;

function startQuiz(){
    currentQuestionIndex=0;
    score=0;
    nextButton.innerHTML='Next';
    showQuestion();
}
function showQuestion(){
    resetState();
    let currentQuestion=questions[currentQuestionIndex];
    let questionNo=currentQuestionIndex+1;      
    questionElement.innerHTML=questionNo+'. '+currentQuestion.question;
    currentQuestion.answers.forEach(answer=>{
        const button=document.createElement('button');
        button.innerHTML=answer.text;   
        button.classList.add('btn');
        answerButtons.appendChild(button);  
        if(answer.correct){
            button.dataset.correct=answer.correct;
        }   
        button.addEventListener('click',selectAnswer);
    });
}   

function resetState(){
    nextButton.style.display='none';
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }   
}

function selectAnswer(e){
    const selectedBtn=e.target;
    const isCorrect=selectedBtn.dataset.correct==='true';       
    if(isCorrect){
        selectedBtn.classList.add('correct');
        score++;    
    }
    else{
        selectedBtn.classList.add('incorrect');
        score=score;
    }   
    Array.from(answerButtons.children).forEach(button=>{
        if(button.dataset.correct==='true'){
            button.classList.add('correct');
        }   
        button.disabled=true;
    });
    nextButton.style.display='block';
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex<questions.length){
        showQuestion();
    }
    else{
        showScore();
    }
}


nextButton.addEventListener('click',()=>{{
    if(currentQuestionIndex<questions.length){
        handleNextButton();
    }
    else{
        startQuiz();
    }   
}});
function showScore(){
    resetState();
    questionElement.innerHTML=`You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML='Play Again';
    nextButton.style.display='block';
}   
startQuiz();

