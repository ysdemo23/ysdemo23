let input=document.getElementById("myInput");
let buttons=document.querySelectorAll("button");

//input from buttons in string
let string="";

//buttons array
let arr=Array.from(buttons);

arr.forEach(button=>{
    button.addEventListener("click",(e)=>{
        let btnText=e.target.innerText;
    
        if(btnText=="AC"){  
            string="";
            input.value=string;
        }       
        else if(btnText=="DEL"){
            string=string.slice(0,-1);
            input.value=string;
        }   
        else if(btnText=="="){
            input.value=eval(string);
        }
        else{
            string+=btnText;
            // string=eval(string);
            input.value=string;
        }       
    });
});
