import logo from './logo.svg';
import './App.css';
import Header from './Components/Header';
import TaskList from './Components/TaskList';
import { Footer } from './Components/Footer';
import { AddTaskForm } from './Components/AddTaskForm';
import { useState } from 'react';

function App() {
   const [tasks,setTasks]=useState([{id:1,name:"Record Lecture",completed:false},
                                                                        ]);
// used concept of state lifting to manage tasks state in App component and pass it down to AddTaskForm and TaskList components as props
  return (
    <div className="App">
      <Header />
      <main>
        <AddTaskForm tasks={tasks} setTasks={setTasks}/>
        <TaskList tasks={tasks} setTasks={setTasks} />
      </main>
      <Footer />
    </div>
  );
}

export default App;
