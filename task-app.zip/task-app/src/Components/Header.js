import React from 'react'
import Logo from "../assets/images.jpg"
import "./Header.css"
function Header() {
  return (
    <header> 
        <img src={Logo} alt="" className='logo1'/>
        <a href="/">Home</a>
    </header>
  )
}

export default Header