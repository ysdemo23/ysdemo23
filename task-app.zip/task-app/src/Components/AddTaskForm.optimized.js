import React, { useState, useRef, useCallback } from 'react';
import "./AddTaskForm.css";

export const AddTaskForm = ({ tasks, setTasks }) => {
  const [taskCompleted, setTaskCompleted] = useState(false);
  const taskValueRef = useRef("");
  const taskIdRef = useRef("");

  // Memoized callback to handle input change
  const handleChange = useCallback((e) => {
    // Input handling - can be extended as needed
  }, []);

  // Memoized callback to reset form
  const handleReset = useCallback(() => {
    taskValueRef.current.value = "";
    taskIdRef.current.value = "";
    setTaskCompleted(false);
  }, []);

  // Memoized callback to handle form submission
  const handleSubmit = useCallback((e) => {
    e.preventDefault();

    const taskValue = taskValueRef.current.value.trim();

    // Validation check
    if (!taskValue) {
      alert("Please enter a task name");
      return;
    }

    const taskId = Math.floor(Math.random() * 1000000);

    const taskData = {
      name: taskValue,
      completed: taskCompleted,
      id: taskId,
    };

    // Update tasks state with new task
    setTasks((prevTasks) => [...prevTasks, taskData]);

    // Update task ID display
    taskIdRef.current.value = taskId;

    // Reset form after submission
    handleReset();
  }, [taskCompleted, setTasks, handleReset]);

  // Memoized checkbox change handler
  const handleCheckboxChange = useCallback((e) => {
    setTaskCompleted(e.target.checked);
  }, []);

  return (
    <section className="add-task-form">
      <h2>Add New Task</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-control">
          <label htmlFor="task-name">Task Name:</label>
          <input
            onChange={handleChange}
            type="text"
            id="task-name"
            name="task-name"
            placeholder="Enter task name"
            ref={taskValueRef}
            required
          />
        </div>
        <div className="form-control">
          <label htmlFor="task-completed">
            Completed (CLICK) / Incomplete:
          </label>
          <input
            onChange={handleCheckboxChange}
            type="checkbox"
            id="task-completed"
            name="task-completed"
            checked={taskCompleted}
          />
        </div>
        <div className="form-control">
          <label htmlFor="task-id">Task ID:</label>
          <input
            type="text"
            id="task-id"
            name="task-id"
            placeholder="Enter task ID"
            disabled
            ref={taskIdRef}
          />
        </div>
        <button type="submit" className="add-task-button">
          Add Task
        </button>
        <span className="reset" onClick={handleReset} role="button" tabIndex={0}>
          Reset
        </span>
      </form>
    </section>
  );
};
