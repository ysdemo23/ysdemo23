import React from 'react';
import "./AddTaskForm.css";
import { useState, useRef } from 'react';

export const AddTaskForm = ({tasks,setTasks}) => {
    //const [taskValue, setTaskValue] = React.useState("");
    const [taskCompleted, setTaskCompleted] = React.useState(false);
    const taskValueRef = useRef("");
    const handleChange = (e) => {
        //setTaskValue(taskValueRef.current.value);
        console.log("Task Value:", taskValueRef.current.value);
    }
    const handleReset = (event) => {
        taskValueRef.current.valueOf = "";
        if (taskCompleted.checked === true) {
            //event.preventDefault();
            //event.taskCompleted.checked = false;
            setTaskCompleted(false);
        }
        document.getElementById("task-id").value = "";
        //document.getElementById("task-name").value = "";
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        var taskId = Math.floor(Math.random() * 1000000);
       
        // Further processing can be done here
        var taskData = {
            name: taskValueRef.current.value,
            completed: taskCompleted,
            id: taskId
    }
    console.log("Form submitted with task:", taskData);
    document.getElementById("task-id").value = taskId;
    setTasks([...tasks, taskData]);  //spread operator to add new task to existing tasks
    handleReset();
    }
  return (
    <section className="add-task-form">
        <h2>Add New Task</h2>
        <form onSubmit={handleSubmit}>  
            <div className="form-control">
                <label htmlFor="task-name">Task Name:</label>
                <input onChange={handleChange} type="text" id="task-name" name="task-name" placeholder="Enter task name" ref={taskValueRef}/>
            </div>
            <div className="form-control">
                <label htmlFor="task-completed">Completed (CLICK)/ Incomplete :   </label>
                <input onChange={(e)=>setTaskCompleted(e.target.checked)} type="checkbox" id="task-completed" name="task-completed" />
            </div>
            <div className="form-control">
                <label htmlFor="task-id">Task ID:</label>
                <input type="text" id="task-id" name="task-id" placeholder="Enter task ID" disabled/>
            </div>
            <button type="submit" className="add-task-button">Add Task</button>
            <span className='reset' onClick={handleReset}>Reset</span>
        </form>
        
  </section>
  )
}
