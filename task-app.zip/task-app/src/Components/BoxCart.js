import React from 'react';
export const BoxCart = ({ result , children}) => {
    const[show, setShow] = React.useState(true);
    return (
    <div className={show? "" : "hidden"}>
      <div className={`box1 ${result}`}>
          {children}
          <button onClick={()=>setShow(!show)} className="trigger">Hide</button>
      </div>
    </div>
  )
}

/* State for success, warning, alert box are created using BoxCart component with prop 'result' and they are different from each other
and maintain their customizations i.e. 2 <p> or 3<p> within them
we can say that each component is independent and use their own state*/