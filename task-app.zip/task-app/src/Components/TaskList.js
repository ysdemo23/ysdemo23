import React from 'react'
import { useState } from 'react';
import { TaskCard } from './TaskCard';
import { BoxCart } from './BoxCart';
import "./TaskList.css";
export default function TaskList({tasks,setTasks}) {
    //  const [tasks,setTasks]=useState([{id:1,name:"Record Lecture",completed:false},
    //                                 {id:2, name:"Take presenty",completed:true},
    //                                 {id:3, name:"Take assessment", completed:false}]);


    const [show, setShow] = useState(true);

    function handleDelete(id){
        //console.log(id)
        setTasks(tasks.filter(task => task.id!==id));

    }
  return (
    <section className='tasklist'>
         {/* <h1> Tasks with {props.title} {props.subtitle} </h1> */}
        <ul>
            <div className='header'>
                <h2> Task List </h2>
                <button className="trigger" onClick={()=>setShow(!show)}>Show/Hide</button>
            </div>
            {
                show && tasks.map((task)=>(      <TaskCard key={task.id} task={task} handleDelete={handleDelete} />
            ))
            }
            
        </ul>
        {/* <BoxCart result="success">
            <p className="title">About Success page</p>
            <p className='description'>This page demonstrates the use of React State and Props. The TaskList component maintains a list of tasks in its state and renders them dynamically. Each task can be deleted using the Delete button, which updates the state accordingly. The TaskCard component is used to display individual tasks, showcasing the use of props to pass data and functions between components.</p>
        </BoxCart>

        <BoxCart result="warning">
                <p className="title">About Warning page</p>
                <p className='description'>This page demonstrates the use of React State and Props. The TaskList component maintains a list of tasks in its state and renders them dynamically. Each task can be deleted using the Delete button, which updates the state accordingly. The TaskCard component is used to display individual tasks, showcasing the use of props to pass data and functions between components.</p>
                <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad soluta facere nisi in, laborum atque maxime non tenetur ex blanditiis repellendus numquam quisquam eveniet dolores rerum amet a iusto beatae! </p> 
        </BoxCart>
        <BoxCart result="alert">
                <p className="title">About Alert page</p>
                <p className='description'>This page demonstrates the use of React State and Props. The TaskList component maintains a list of tasks in its state and renders them dynamically. Each task can be deleted using the Delete button, which updates the state accordingly. The TaskCard component is used to display individual tasks, showcasing the use of props to pass data and functions between components.</p>
        </BoxCart> */}
    </section>
  )
}
