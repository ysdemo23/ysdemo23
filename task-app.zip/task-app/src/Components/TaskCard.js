import React from 'react'
import "./TaskCard.css";
export const TaskCard = ({task,handleDelete}) => {
  return (
        <li className={`taskcard ${task.completed? "completed": "incomplete"}`}>
                    <span> {task.id} - {task.name} </span>
                    <button onClick={()=> handleDelete(task.id)} className="delete"> Delete </button>
        </li>
  )
}

/* one can add more than one classname using backtick with conditional classname as on line no 5*/