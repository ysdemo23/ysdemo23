import React from 'react'
import "./Footer.css"

export const Footer = () => {
  return (
    <footer>
        <p> CopyRight - 2025 - TaskMate</p>
    </footer>
  )
}
